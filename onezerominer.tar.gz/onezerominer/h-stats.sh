
stats_raw=`curl --connect-timeout 2 --max-time $API_TIMEOUT --silent --noproxy '*' http://127.0.0.1:63002`
if [[ $? -ne 0 || -z $stats_raw ]]; then
  echo -e "${YELLOW}Failed to read stats from http://127.0.0.1:63002"
else
  local temp=$(jq '.temp' <<< $gpu_stats)
	local fan=$(jq '.fan' <<< $gpu_stats)
	local ver=`echo $stats_raw | jq -c -r ".version"`
  local bus_numbers=$(echo $stats_raw | jq -r ".devices[].bus_id" |  jq -sc .)
  local algo="dynexsolve"
  local ac=`echo $stats_raw | jq -c -r ".algos[].total_accepted_shares"`
  local inv=`echo $stats_raw | jq -c -r ".algos[].total_rejected_shares"` 
  local uptime=`echo $stats_raw | jq -c -r ".uptime_seconds"`


  units="hs"
  hs=`echo $stats_raw | jq -r ".algos[].total_hashrate"`
  khs=$(jq -n --argjson hs "$hs" '$hs / 1000')
  
  
  echo $stats_raw
  stats=$(jq --arg ac "$ac" --arg inv "$inv" \
          --arg algo "$algo" \
          --arg ver "$ver" --arg uptime "$uptime" \
          --argjson fan "$fan" --argjson temp "$temp" \
          --argjson bus_numbers "$bus_numbers" \
          --arg units "$units" \
          '{hs: .algos[].hashrates, hs_units: $units,  $temp, $fan, $algo, $uptime, ar: [$ac, $inv], $bus_numbers, $ver}' <<< "$stats_raw")

  echo $stats
fi

[[ -z $khs ]] && khs=0
[[ -z $stats ]] && stats="null"