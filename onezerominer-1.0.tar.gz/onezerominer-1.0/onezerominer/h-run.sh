#!/usr/bin/env bash

. h-manifest.conf

./onezerominer $(< ./$CUSTOM_NAME.conf) --api-port=${CUSTOM_API_PORT} | tee $CUSTOM_LOG_BASENAME.log
